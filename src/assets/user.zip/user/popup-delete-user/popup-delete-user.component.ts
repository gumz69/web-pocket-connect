import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output, input } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-popup-delete-user',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './popup-delete-user.component.html',
  styleUrl: './popup-delete-user.component.css'
})
export class PopupDeleteUserComponent implements OnInit{
  constructor(
    private router: Router,
    public dialogRef: MatDialogRef<PopupDeleteUserComponent>) {}
    @Input() data: string='';
    ngOnInit(): void {
        console.log(this.data)
    }
    @Output() confirmed = new EventEmitter<boolean>();

    confirm() {
      // this.confirmed.emit(true);
      console.log(this.data)
    }

    cancel() {
      this.confirmed.emit(false);
    }

    refreshPage(): void {
      this.router.navigateByUrl('/user');
    }
    cancelAndClosePopup(): void {
      this.dialogRef.close();
    }
}